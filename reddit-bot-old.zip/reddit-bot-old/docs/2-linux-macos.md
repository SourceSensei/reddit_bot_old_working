# Running the bot on Linux and Macos

Run the `run_linux.sh` script in the root of the repo. This script was designed and tested on Ubuntu 20, so that's what you should be using. It should also work on the latest version of macOS.

The script will install all OS level dependencies required by the bot, as well as installing python dependencies into a vitual enviroment. After everything has been installed it will automatically run the bot.
